using System;
using WindowsFormsApp1;
using Xunit;

namespace LivroTest
{
    public class UnitTest1
    {
        [Fact]
        public void TestCamposPreenchidos()
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor("Autor");
            livro.setEditora("Editora");
            livro.setAnoEdicao("2022");
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.False(Erro.getErro());
        }

        [Theory]
        [InlineData("")]
        [InlineData("T�tulo")]
        public void TestCampoTitulo(string titulo)
        {
            Livro livro = new Livro();
            livro.setTitulo(titulo);
            livro.setAutor("Autor");
            livro.setEditora("Editora");
            livro.setAnoEdicao("2022");
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }

        [Theory]
        [InlineData("")]
        [InlineData("Autor")]
        public void TestCampoAutor(string autor)
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor(autor);
            livro.setEditora("Editora");
            livro.setAnoEdicao("2022");
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }

        [Theory]
        [InlineData("")]
        [InlineData("Editora")]
        public void TestCampoEditora(string editora)
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor("Autor");
            livro.setEditora(editora);
            livro.setAnoEdicao("2022");
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }

        [Theory]
        [InlineData("")]
        [InlineData("2022")]
        public void TestCampoAno(string ano)
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor("Autor");
            livro.setEditora("Editora");
            livro.setAnoEdicao(ano);
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }

        [Theory]
        [InlineData("")]
        [InlineData("Local")]
        public void TestCampoLocal(string local)
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor("Autor");
            livro.setEditora("Editora");
            livro.setAnoEdicao("2022");
            livro.setLocal(local);

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }



        [Fact]
        public void TestAnoEdicaoNaoNumerico()
        {
            Livro livro = new Livro();
            livro.setTitulo("T�tulo");
            livro.setAutor("Autor");
            livro.setEditora("Editora");
            livro.setAnoEdicao("Ano");
            livro.setLocal("Local");

            LivroBLL.validaDados(livro);

            Assert.True(Erro.getErro());
        }
    }

}