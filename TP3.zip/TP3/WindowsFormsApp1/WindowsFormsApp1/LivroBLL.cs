﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class LivroBLL
    
        {
            public static void validaDados(Livro livro)
            {
                Erro.setErro(false);
                if (livro.getTitulo().Length == 0 || livro.getAutor().Length == 0 || livro.getEditora().Length == 0 || livro.getAnoEdicao().Length == 0 || livro.getLocal().Length == 0)
                {
                    Erro.setErro("O campo é de preenchimento obrigatório...");
                    return;
                }
                else
                {
                    try
                    {
                        float.Parse(livro.getAnoEdicao());
                    }
                    catch
                    {
                        Erro.setErro("O campo Ano deve ser numérico...");
                        return;
                    }
                    if (float.Parse(livro.getAnoEdicao()) <= 0)
                    {
                        Erro.setErro("O campo deve ser maior que zero.");
                        return;
                    }
                }



            }
        }
    }

