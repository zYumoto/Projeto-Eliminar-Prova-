﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Livro livro = new Livro();
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox1.Focus();
        }

     
        private void button2_Click_1(object sender, EventArgs e)
        {
            livro.setTitulo(textBox1.Text);
            livro.setAutor(textBox2.Text);
            livro.setEditora(textBox3.Text);
            livro.setAnoEdicao(textBox4.Text);
            livro.setLocal(textBox5.Text);
            LivroBLL.validaDados(livro);

            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMens());
            }
            else
            {
                MessageBox.Show("Salvo com sucesso");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox1.Focus();


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = livro.getTitulo();
            textBox2.Text = livro.getAutor();
            textBox3.Text = livro.getEditora();
            textBox4.Text = livro.getAnoEdicao();
            textBox5.Text = livro.getLocal();
        }
    }
}
